
  
<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col col-sm-11 col-md-10 col-lg-8">
            <div class="row">
                <div class="col-sm">
                    <h1 class="category_title after"><?php echo e($categoria); ?></h1>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col col-sm-11 col-md-10 col-lg-8">
            <div class="row">

            <?php $__currentLoopData = $eventsSelected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventSelected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <div class="card category_card">
                        <img src="../img/<?php echo e($eventSelected->img); ?>" class="card-img-top category-card-img" alt="<?php echo e($eventSelected->titulo); ?>">
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($eventSelected->titulo); ?></h2>

                            <h3 class="card-text">₡<?php echo e($eventSelected->precio); ?></h3>

                            <p class="card-text"><?php echo e($eventSelected->lugar); ?> <br /> <?php echo e($eventSelected->categoria); ?></p>

                            <a href="/event_detail" aria-label="Enter to event"><i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row">
                <button class="btn_backHome_confirmation">Ver más</button>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\laragon\www\heliumstorelaravel\resources\views//category.blade.php ENDPATH**/ ?>
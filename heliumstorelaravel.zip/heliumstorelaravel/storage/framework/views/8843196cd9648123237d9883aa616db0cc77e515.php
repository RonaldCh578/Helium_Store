
  
<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col col-sm-11 col-md-10 col-lg-8 fit_to_border">
            <div class="event_back_cover">
                <img src="../img/<?php echo e($eventDetail[0]->img); ?>" alt="Contra portada de concierto de música Pop">
                <div class="row align-items-center inner">
                    <img src="../img/<?php echo e($eventDetail[0]->img); ?>" alt="Portada de concierto de música Pop">
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col col-sm-11 col-md-10 col-lg-8">

            <div class="row">
                <div class="col-sm event_detail">

                    <h1><?php echo e($eventDetail[0]->titulo); ?></h1>

                    <div class="row">
                        <div class="col p-0">
                            <h3 class="m-0"><?php echo e($eventDetail[0]->lugar); ?></h3>
                        </div>
                        <div class="col p-0">
                            <h2 class="m-0">₡<?php echo e($eventDetail[0]->precio); ?></h2>
                        </div>
                    </div>

                    <h3><?php echo e($eventDetail[0]->categoria); ?></h3>
                    <h3><?php echo e($eventDetail[0]->tipo_publico); ?></h3>

                    <p><?php echo e($eventDetail[0]->descripcion); ?></p>
                </div>
            </div>

            <form action="/shop_info" method="get">

                <div class="row">

                    <div class="col col-sm-11 col-md-10 col-lg-8">

                        <div class="select_box">

                            <div class="selected">
                                Seleccione una fecha
                            </div>

                            <div class="options_container">

                                <div class="option" onclick="changeSelected('lbl_schedule1')">
                                    <input type="radio" id="schedule1" name="optionSchedule" value="1">
                                    <label for="schedule1" id="lbl_schedule1">Lunes 17 de mayo - 1:00
                                        p.m.</label>
                                </div>

                                <div class="option" onclick="changeSelected('lbl_schedule2')">
                                    <input type="radio" id="schedule2" name="optionSchedule" value="2">
                                    <label for="schedule2" id="lbl_schedule2">Martes 25 de mayo - 1:00
                                        p.m.</label>
                                </div>

                                <div class="option" onclick="changeSelected('lbl_schedule3')">
                                    <input type="radio" id="schedule3" name="optionSchedule" value="3">
                                    <label for="schedule3" id="lbl_schedule3">Lunes 1 de junio - 1:00
                                        p.m.</label>
                                </div>

                                <div class="option" onclick="changeSelected('lbl_schedule4')">
                                    <input type="radio" id="schedule4" name="optionSchedule" value="4">
                                    <label for="schedule4" id="lbl_schedule4">Martes 9 de junio - 1:00
                                        p.m.</label>
                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="col-sm-4">

                        <div class="submit_event_detail">
                            <button type="submit" aria-label="Buy tickets">Registrarse</button>
                        </div>

                    </div>

                </div>

            </form>

            <div class="row">
                <div class="col-sm">
                    <h2 class="after">Eventos relacionados</h2>
                </div>
            </div>

            <div class="row">

                <div class="col-sm-4">
                    <div class="card events_related">
                        <img src="../img/concierto01.jpg" class="card-img-top" alt="Concierto 01">
                        <div class="card-body">
                            <a href="/event_detail">Leer más</a>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="card events_related">
                        <img src="../img/concierto01.jpg" class="card-img-top" alt="Concierto 01">
                        <div class="card-body">
                            <a href="/event_detail">Leer más</a>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="card events_related">
                        <img src="../img/concierto01.jpg" class="card-img-top" alt="Concierto 01">
                        <div class="card-body">
                            <a href="/event_detail">Leer más</a>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="card events_related">
                        <img src="../img/concierto01.jpg" class="card-img-top" alt="Concierto 01">
                        <div class="card-body">
                            <a href="/event_detail">Leer más</a>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <a class="btn_backHome_confirmation" href="/category#category">Ver más</a>
                </div>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH B:\laragon\www\heliumstorelaravel\resources\views/event_detail.blade.php ENDPATH**/ ?>